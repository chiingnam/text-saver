const config = {
  "extends": "airbnb-base"
};

module.exports = config;