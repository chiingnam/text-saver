---
layout: page
title: Privacy policy
permalink: /privacy/
---

Your privacy policy here
Use this to generate one for free: https://www.freeprivacypolicy.com/free-privacy-policy-generator.php